export interface UserResponse {
    title: string; // Assuming this is the title of the quiz or question
    user: string; // Assuming it's the ID of the user
    questionType: 'Multiple Choice' | 'Text Input';
    questionBody: string;
    userAnswer: string;
  }
  