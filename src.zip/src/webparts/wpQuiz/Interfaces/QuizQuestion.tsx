export interface QuizQuestion {
    title: string;
    questionType: 'Multiple Choice' | 'Text Input';
    questionBody: string;
    options?: string; // Only applicable if questionType is 'Multiple Choice'
    correctAnswer?: string; // Only applicable if questionType is 'Multiple Choice'
  }
  