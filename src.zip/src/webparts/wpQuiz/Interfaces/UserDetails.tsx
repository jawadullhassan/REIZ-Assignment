export interface UserDetails {
    name: string;
    email: string;
    department: string;
    role: string;
    country: string;
    dateJoined?: Date;
    user?: string; // Assuming it's the ID of the user
  }
  