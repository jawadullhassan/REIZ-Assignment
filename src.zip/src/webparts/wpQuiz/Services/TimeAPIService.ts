export default class TimeAPIService {
    static async fetchCurrentTimeByCountry(country: string): Promise<string> {
      try {
        const response = await fetch(`https://timeapi.io/api/Time/current/zone?timeZone=${country}`);
        const data = await response.json();
        return data.dateTime;
      } catch (error) {
        console.error('Error fetching current time:', error);
        throw new Error('Failed to fetch current time');
      }
    }
  }
  