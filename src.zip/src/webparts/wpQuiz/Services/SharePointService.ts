import { sp } from '@pnp/sp';
import { UserDetails, QuizQuestion, UserResponse } from '../Interfaces';

export default class SharePointService {
  static async fetchUserDetails(): Promise<UserDetails> {
    const userDetails = await sp.web.lists.getByTitle('UserDetails').items.get();
    return userDetails[0]; // Assuming there's only one user detail record
  }

 // static async fetchQuizQuestions(): Promise<QuizQuestion[]> {
  //  return sp.web.lists.getByTitle('QuizList').items.get();
 // }

  static async submitUserResponse(response: UserResponse): Promise<any> {
    return sp.web.lists.getByTitle('QuizResponsesList').items.add(response);
  }
}
