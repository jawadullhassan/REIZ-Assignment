import React, { useEffect, useState } from 'react';
import UserDetailsForm from '../components/UserDetailsForm';
import QuizListStep from '../components/QuizListStep';
import QuizForm from '../components/QuizForm';
import TimerComponent from '../components/TimerComponent';
import SharePointService from '../Services/SharePointService';
import TimeAPIService from '../Services/TimeAPIService';
import { UserDetails, QuizQuestion, UserResponse } from '../Interfaces';
import styles from '../Styles/formStyles.module.scss';

const QuizPage: React.FC = () => {
  const [step, setStep] = useState(1);
  const [userDetails, setUserDetails] = useState<UserDetails | null>(null);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [userResponses, setUserResponses] = useState<UserResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [timerStarted, setTimerStarted] = useState(false);

  useEffect(() => {
    fetchUserDetails();
    fetchQuizQuestions();
  }, []);

  const fetchUserDetails = async () => {
    try {
      const data = await SharePointService.fetchUserDetails();
      setUserDetails(data);
    } catch (error) {
      console.error('Error fetching user details:', error);
    }
  };

  const fetchQuizQuestions = async () => {
    try {
      const data = await SharePointService.fetchQuizQuestions();
      setQuizQuestions(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching quiz questions:', error);
    }
  };

  const handleSubmitUserDetails = (userData: UserDetails) => {
    setUserDetails(userData);
    setStep(2);
  };

  const handleSubmitQuiz = (answers: string[]) => {
    const responses: UserResponse[] = quizQuestions.map((question, index) => ({
      title: question.title,
      user: userDetails?.user || '',
      questionType: question.questionType,
      questionBody: question.questionBody,
      userAnswer: answers[index]
    }));
    setUserResponses(responses);
    setStep(3);
  };

  const handleStartQuiz = () => {
    setStep(3);
    setTimerStarted(true);
  };

  const handleTimerComplete = async () => {
    const country = userDetails?.country || '';
    const currentTime = await TimeAPIService.fetchCurrentTimeByCountry(country);
    console.log('Current time in user\'s country:', currentTime);
    // Additional logic after timer completes
  };

  return (
    <div className={styles.container}>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          {step === 1 && <UserDetailsForm onSubmit={handleSubmitUserDetails} />}
          {step === 2 && <QuizListStep quizQuestions={quizQuestions} onStartQuiz={handleStartQuiz} />}
          {step === 3 && (
            <>
              <TimerComponent seconds={60} onComplete={handleTimerComplete} />
              <QuizForm questions={quizQuestions} onSubmit={handleSubmitQuiz} />
            </>
          )}
        </>
      )}
    </div>
  );
};

export default QuizPage;
