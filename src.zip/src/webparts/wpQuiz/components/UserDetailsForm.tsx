import React, { useState } from 'react';
import { UserDetails } from '../Interfaces';
import styles from '../styles/formStyles.module.scss';

interface UserDetailsFormProps {
  onSubmit: (userData: UserDetails) => void;
}

const UserDetailsForm: React.FC<UserDetailsFormProps> = ({ onSubmit }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [department, setDepartment] = useState('');
  const [role, setRole] = useState('');
  const [country, setCountry] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const userData: UserDetails = {
      name,
      email,
      department,
      role,
      country
    };
    onSubmit(userData);
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <label className={styles.label}>
        Name:
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} className={styles.input} />
      </label>
      <label className={styles.label}>
        Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={styles.input} />
      </label>
      <label className={styles.label}>
        Department:
        <select value={department} onChange={(e) => setDepartment(e.target.value)} className={styles.input}>
          <option value="">Select Department</option>
          {/* Add department options */}
        </select>
      </label>
      <label className={styles.label}>
        Role:
        <select value={role} onChange={(e) => setRole(e.target.value)} className={styles.input}>
          <option value="">Select Role</option>
          {/* Add role options */}
        </select>
      </label>
      <label className={styles.label}>
        Country:
        <input type="text" value={country} onChange={(e) => setCountry(e.target.value)} className={styles.input} />
      </label>
      <button type="submit" className={styles.button}>Next</button>
    </form>
  );
};

export default UserDetailsForm;
