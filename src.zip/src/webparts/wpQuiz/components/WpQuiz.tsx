import * as React from 'react';
import { UserDetails } from '../Interfaces/UserDetails';
import { QuizQuestion } from '../Interfaces/QuizQuestion';
import { Stylesheet } from '../Styles/formStyles.module.scss';
//import Style from '../Styles/formStyles.module.scss';
//import type { IWpQuizProps } from './IWpQuizProps';
//import { escape } from '@microsoft/sp-lodash-subset';


interface QuizListStepProps {
  quizQuestions: QuizQuestion[];
  onStartQuiz: () => void;
}

export default class WpQuiz extends React.Component<UserDetails, {}> {
  public render(): React.ReactElement<UserDetails> {
    
    const QuizListStep: React.FC<QuizListStepProps> = ({ quizQuestions, onStartQuiz }) => {
      return (
        <div className={styles.quizList}>
          <h2>Quiz Questions</h2>
          <ul>
            {quizQuestions.map((question, index) => (
              <li key={index} className={styles.quizQuestion}>
                <h3>{question.title}</h3>
                <p>Type: {question.questionType}</p>
                <p>{question.questionBody}</p>
                <p>Options: {question.options}</p>
              </li>
            ))}
          </ul>
          <button onClick={onStartQuiz} className={styles.button}>Start Quiz</button>
        </div>
      );
    };
    
  }
}
