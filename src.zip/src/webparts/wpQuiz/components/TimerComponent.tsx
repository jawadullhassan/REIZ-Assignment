//import React from 'react';
import { useState, useEffect } from 'react';
import styles from '../Styles/formStyles.module.scss';
import * as React from 'react';

interface TimerComponentProps {
  seconds: number;
  onComplete: () => void;
}

const TimerComponent: React.FC<TimerComponentProps> = ({ seconds, onComplete }) => {
  const [timeLeft, setTimeLeft] = useState(seconds);

  useEffect(() => {
    const timer = setInterval(() => {
      if (timeLeft === 0) {
        clearInterval(timer);
        onComplete();
      } else {
        setTimeLeft((prevTime) => prevTime - 1);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onComplete]);

  return <div className={styles.timer}>{timeLeft} seconds left</div>;
};

export default TimerComponent;
