import React from 'react';
import { QuizQuestion } from '../Interfaces';
import styles from '../Styles/formStyles.module.scss';

interface QuizListStepProps {
  quizQuestions: QuizQuestion[];
  onStartQuiz: () => void;
}

const QuizListStep: React.FC<QuizListStepProps> = ({ quizQuestions, onStartQuiz }) => {
  return (
    <div className={styles.quizList}>
      <h2>Quiz Questions</h2>
      <ul>
        {quizQuestions.map((question, index) => (
          <li key={index} className={styles.quizQuestion}>
            <h3>{question.title}</h3>
            <p>Type: {question.questionType}</p>
            <p>{question.questionBody}</p>
            <p>Options: {question.options}</p>
          </li>
        ))}
      </ul>
      <button onClick={onStartQuiz} className={styles.button}>Start Quiz</button>
    </div>
  );
};

export default QuizListStep;
